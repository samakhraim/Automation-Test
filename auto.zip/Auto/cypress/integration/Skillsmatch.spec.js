

describe('skillsmatch ',()=>  {
it ('search first test case ',()=> {
cy.visit('https://skillsmatch.mdx.ac.uk/en/search/')
cy.url().should('include','skillsmatch.mdx')
cy.xpath("//input[@id='username']").type('samai')
cy.xpath("//input[@id='password']").type('samaidgaf')
cy.xpath("//input[@value='Login']").click()
cy.xpath("//span[@role='textbox']").type('management')
cy.xpath("//a[@class='collapsed card-link']").click ()
cy.xpath("//input[@id='match_all']").click ()
cy.xpath("//div[@class='container']").click ()
cy.xpath("//button[normalize-space()='Search']").click()
cy.xpath("//div[@class='container']//div[1]//div[1]//h4[1]//a[1]").click ()
cy.xpath("//a[normalize-space()='Search']").click()
})
it('search second  test case ',()=>{
    cy.visit('https://skillsmatch.mdx.ac.uk/en/search/')
cy.url().should('include','skillsmatch.mdx')
cy.xpath("//input[@id='username']").type('samai')
cy.xpath("//input[@id='password']").type('samaidgaf')
cy.xpath("//input[@value='Login']").click()
    cy.xpath("//span[@role='textbox']").type('management')
    cy.xpath("//a[@class='collapsed card-link']").click ()
    cy.xpath("//input[@id='match_all']").click ()
    cy.xpath("//input[@id='search_in_title']").click ()

    cy.xpath("//div[@class='container']").click ()
    cy.xpath("//button[normalize-space()='Search']").click()
    cy.xpath("//a[normalize-space()='Search']").click()


})


    })